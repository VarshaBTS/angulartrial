import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stupid',
  templateUrl: './stupid.component.html',
  styleUrls: ['./stupid.component.css']
})
export class StupidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
